﻿using SoftUni.Data;
using System;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var context = new SoftUniContext();
            //03. Employees Full Information
            //string result = GetEmployeesFullInformation(context);
            string result = GetEmployeesWithSalaryOver50000(context);
            //Console.WriteLine(result);
            Console.WriteLine(result);

        }

        //03. Employees Full Information

        public static string
            GetEmployeesFullInformation(SoftUniContext context)
        {
            var employees = context.Employees
                .Select(e => new
                {
                    e.EmployeeId,
                    e.FirstName,
                    e.LastName,
                    e.MiddleName,
                    e.JobTitle,
                    e.Salary
           
                }
                )
                .OrderBy(e => e.EmployeeId)
                .ToList();
           
            StringBuilder result = new StringBuilder();
           
            foreach (var employee in employees)
            {
                result.AppendLine(
                    $"{employee.FirstName} {employee.LastName} {employee.MiddleName} {employee.JobTitle} {employee.Salary:f2}");
            }
           
            return result.ToString().Trim();  
        }

        //04. Employees with Salary Over 50 000
        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            var employees = context.Employees
           .Select(e => new
           {
               e.FirstName,
               e.Salary
           })
           .Where(e => e.Salary > 50000)
           .OrderBy(e => e.FirstName);

            StringBuilder sb = new StringBuilder();

            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} - {employee.Salary:f2}");
            }

            return sb.ToString().TrimEnd();
        }

       
         
    }
}
