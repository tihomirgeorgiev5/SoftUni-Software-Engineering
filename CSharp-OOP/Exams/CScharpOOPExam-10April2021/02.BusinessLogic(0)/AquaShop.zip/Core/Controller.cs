﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AquaShop.Core
{
    class Controller
    {
    }
}
