﻿namespace Git.Models.Commits
{
    public class CommitToRepositoryViewModel
    {
        public string Id { get; init; }

        public string Name { get; init; }
    }
}
