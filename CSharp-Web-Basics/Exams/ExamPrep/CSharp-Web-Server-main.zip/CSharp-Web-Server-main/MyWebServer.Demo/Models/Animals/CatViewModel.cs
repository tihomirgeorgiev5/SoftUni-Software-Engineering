﻿namespace MyWebServer.Demo.Models.Animals
{
    public class CatViewModel
    {
        public string Name { get; init; }

        public int Age { get; init; }
    }
}
