﻿namespace CarShop.Models.Issues
{
    public class AddIssueFormModel
    {
        public string Description { get; init; }

        public string CarId { get; init; }
    }
}
