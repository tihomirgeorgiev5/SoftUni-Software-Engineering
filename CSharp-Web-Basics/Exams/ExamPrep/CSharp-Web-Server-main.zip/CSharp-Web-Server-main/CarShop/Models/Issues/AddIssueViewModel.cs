﻿namespace CarShop.Models.Issues
{
    public class AddIssueViewModel
    {
        public string CarId { get; init; }
    }
}
