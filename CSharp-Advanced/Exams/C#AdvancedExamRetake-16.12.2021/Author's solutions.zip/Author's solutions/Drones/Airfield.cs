﻿using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drones
{
    public class Airfield
    {
        private readonly ICollection<Drone> drones;

        public Airfield(string name, int capacity, double landingStrip)
        {
            Name = name;
            Capacity = capacity;
            LandingStrip = landingStrip;
            drones = new HashSet<Drone>();
        }

        public string Name { get; set; }
        public int Capacity { get; set; }
        public double LandingStrip { get; set; }
        public IReadOnlyCollection<Drone> Drones => (IReadOnlyCollection<Drone>)this.drones;
        public int Count =>
        this.Drones.Count;

        public string AddDrone(Drone drone)
        {
            var currentRange = drone.Range < 5 || drone.Range > 15;
            if (string.IsNullOrEmpty(drone.Name) ||
                string.IsNullOrEmpty(drone.Brand) ||
                currentRange)
            {
                return "Invalid drone.";
            }

            if (drones.Count + 1 > Capacity)
            {
                return "Airfield is full.";
            }
            drones.Add(drone);
            return $"Successfully added {drone.Name} to the airfield.";
        }

        public bool RemoveDrone(string name)
        {
            var drone = drones.FirstOrDefault(x => x.Name == name);
            if (drone is null)
            {
                return false;
            }
            drones.Remove(drone);
            return true;
        }

        public int RemoveDroneByBrand(string brand)
        {
            var brandDrones = drones.Where(x => x.Brand == brand).ToList();
            if (brandDrones is null)
            {
                return 0;
            }

            foreach (var dr in brandDrones)
            {
                drones.Remove(dr);
            }

            return brandDrones.Count();
        }

        public Drone FlyDrone(string name)
        {
            var drone = drones.FirstOrDefault(x => x.Name == name);
            if (drone is null)
            {
                return null;
            }
            drone.Available = false;
            return drone;
        }

        public List<Drone> FlyDronesByRange(int range)
        {
            var flyDrones = drones.Where(x => x.Range >= range).ToList();

            foreach (var item in flyDrones)
            {
                item.Available = false;
            }

            return flyDrones;
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Drones available at {Name}:");

            foreach (Drone drone in this.Drones)
            {
                if (drone.Available)
                {
                    sb.AppendLine(drone.ToString());
                }
            }

            return sb.ToString().TrimEnd();
        }
    }
}
